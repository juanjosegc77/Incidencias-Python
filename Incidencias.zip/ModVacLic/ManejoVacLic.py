#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Juan José Guzmán Cruz'

from PyQt5.QtCore import QDate, QTime
from PyQt5.QtSql import QSqlQuery
from PyQt5.QtWidgets import QMainWindow, QMessageBox

from ModVacLic import VacLic
from ModVacLic.ManejoVacLicUI import Ui_mainWindowManejoVacLic


ui = Ui_mainWindowManejoVacLic()


class ManejoVacLic(QMainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)
        ui.setupUi(self)

    def on_pushButtonCerrar_released(self):
        self.close()

    def on_pushButtonModificar_released(self):
        modificarRegistro(self)

    def on_pushButtonEliminar_released(self):
        eliminarRegistro(self)

def showData(id_alf, id_vaclic, adsc, tarjeta, numemp, nombre, folio, clave, periodo, dias, inicio, articulo,
            uno, dos, tres, cuatro, cinco, seis, siete, ocho, nueve, diez,
            notas, fecha_c, hora_c):
    global find_id
    find_id = id_vaclic

    global v_id_alf
    v_id_alf = id_alf

    ui.lineEditAdsc.setText(adsc)
    ui.lineEditTarjeta.setText(tarjeta)
    ui.lineEditNumEmp.setText(numemp)
    ui.lineEditNombre.setText(nombre)
    ui.lineEditFolio.setText(folio)
    ui.lineEditClave.setText(clave)
    ui.lineEditPeriodo.setText(periodo)
    ui.lineEditDias.setText(dias)
    ui.dateEditInicio.setDate(QDate.fromString(inicio, "dd-MMM-yyyy"))
    ui.lineEditArt.setText(articulo)
    ui.lineEditUno.setText(uno)
    ui.lineEditDos.setText(dos)
    ui.lineEditTres.setText(tres)
    ui.lineEditCuatro.setText(cuatro)
    ui.lineEditCinco.setText(cinco)
    ui.lineEditSeis.setText(seis)
    ui.lineEditSiete.setText(siete)
    ui.lineEditOcho.setText(ocho)
    ui.lineEditNueve.setText(nueve)
    ui.lineEditDiez.setText(diez)
    ui.lineEditNotas.setText(notas)
    ui.dateEditFechaDeCaptura.setDate(QDate.fromString(fecha_c, "dd-MMM-yyyy"))
    ui.timeEditHoraDeCaptura.setTime(QTime.fromString(hora_c, "HH:mm"))

# MODIFICAR UN REGISTRO
def modificarRegistro(self):
    query = ("UPDATE vaclic SET "
             "Folio='"+ui.lineEditFolio.text()+"',"
             "Clave='"+ui.lineEditClave.text()+"',"
             "PeriodoSerie='"+ui.lineEditPeriodo.text()+"',"
             "Dias='"+ui.lineEditDias.text()+"',"
             "Inicio='"+ui.dateEditInicio.text()+"',"
             "Articulo='"+ui.lineEditArt.text()+"',"
             "'1'='"+ui.lineEditUno.text()+"',"
             "'2'='"+ui.lineEditDos.text()+"',"
             "'3'='"+ui.lineEditTres.text()+"',"
             "'4'='"+ui.lineEditCuatro.text()+"',"
             "'5'='"+ui.lineEditCinco.text()+"',"
             "'6'='"+ui.lineEditSeis.text()+"',"
             "'7'='"+ui.lineEditSiete.text()+"',"
             "'8'='"+ui.lineEditOcho.text()+"',"
             "'9'='"+ui.lineEditNueve.text()+"',"
             "'10'='"+ui.lineEditDiez.text()+"',"
             "Notas='"+ui.lineEditNotas.text()+"'"
             "WHERE Id_vaclic='" + str(find_id) + "'")

    actualizar = QSqlQuery()
    actualizar.prepare(query)

    if actualizar.exec_():
        QMessageBox.information(self, "Aviso", "El registro se actualizó correctamente",
                                QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)
        self.close()
        VacLic.cargarVista(v_id_alf)
    else:
        QMessageBox.critical(self, "Error", "NO se actualizó el registro",
                             QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)

# ELIMINAR UN REGISTRO AL PRESIONAR EL BOTON ELIMINAR
def eliminarRegistro(self):
    reply = QMessageBox.question(self, 'Confirmar', "¿Está seguro de eliminar este registro?",
                                 QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
    if reply == QMessageBox.Yes:
        query = ("DELETE FROM vaclic WHERE Id_vaclic ='" + str(find_id) + "'")

        eliminar = QSqlQuery()
        eliminar.prepare(query)

        if eliminar.exec_():
            QMessageBox.information(self, 'Aviso', "El registro se eliminó correctamente",
                                    QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)
            self.close()
            VacLic.cargarVista(v_id_alf)
        else:
            QMessageBox.critical(self, 'Error', u'El registro NO se pudo eliminar. Error en query',
                                 QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)
