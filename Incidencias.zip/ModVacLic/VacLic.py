#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Juan José Guzmán Cruz'
from datetime import date

from PyQt5 import QtGui
from PyQt5.QtCore import QDate, QTime, QRegExp
from PyQt5.QtSql import QSqlQuery
from PyQt5.QtWidgets import QMainWindow, QMessageBox, QInputDialog

from DataBase.ManejoBD import obtenerModelo
from ModVacLic.ManejoVacLic import ManejoVacLic, showData
from ModVacLic.VacLicUI import Ui_mainWindowVacLic

ui = Ui_mainWindowVacLic()


class VacLic(QMainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)
        ui.setupUi(self)

        ui.pushButtonAgregar.setEnabled(False)
        ui.dateEditInicio.setDate(QDate.currentDate())
        validarValoresPermitidos(self)

    def on_pushButtonBuscar_released(self):
        buscar(self)

    def on_pushButtonAgregar_released(self):
        insertarRegistro(self)

    def on_pushButtonCerrar_released(self):
        self.close()

    def on_tableViewRegistrosVacLic_doubleClicked(self, index):
        id_alf = globals()["v_id_alf"]
        reg = index.data()

        if(index.column() == 0):
            query = "SELECT * FROM vaclic WHERE Id_vaclic = %s" % reg

            datos = QSqlQuery()
            datos.prepare(query)

            if datos.exec_():
                while datos.next():
                    folio = datos.value(2)
                    clave = datos.value(3)
                    periodo = datos.value(4)
                    dias = datos.value(5)
                    inicio = datos.value(6)
                    articulo = datos.value(7)
                    uno = datos.value(8)
                    dos = datos.value(9)
                    tres = datos.value(10)
                    cuatro = datos.value(11)
                    cinco = datos.value(12)
                    seis = datos.value(13)
                    siete = datos.value(14)
                    ocho = datos.value(15)
                    nueve = datos.value(16)
                    diez = datos.value(17)
                    notas = datos.value(18)
                    fecha_c = datos.value(19)
                    hora_c = datos.value(20)

                adsc = ui.lineEditAdsc.text()
                tarjeta = ui.lineEditTarjeta.text()
                numemp = ui.lineEditNumEmp.text()
                nombre = ui.lineEditNombre.text()

                self.manejo_vaclic = ManejoVacLic()
                showData(id_alf, reg, adsc, tarjeta, numemp, nombre, folio, clave, periodo, dias, inicio, articulo,
                         uno, dos, tres, cuatro, cinco, seis, siete, ocho, nueve, diez, notas, fecha_c, hora_c)
                self.manejo_vaclic.show()

            else:
                QMessageBox.critical(self, 'Error', u'Error en query', 1, 0)

def buscar(self):
    global v_id_alf

    in_numemp = QInputDialog.getText(self, "Buscar", u"Número de empleado: ")

    out_numemp = str(in_numemp[0])
    buscar = QSqlQuery()
    query = ("SELECT Id, Adsc, Tarjeta, NumEmp, Nombre FROM alfabetico WHERE NumEmp = '%s") %out_numemp + "'"

    buscar.prepare(query)
    if buscar.exec_():
        if buscar.last() == False:
            QMessageBox.information(self, 'Mensaje',
                                    'No existe el ningún registro con el número de empleado:  "'
                                    + out_numemp + '"',
                                    QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)
        elif buscar.last() == True:
            v_id_alf = buscar.value(0)
            v_adsc = buscar.value(1)
            v_tarjeta = buscar.value(2)
            v_numemp = buscar.value(3)
            v_nombre = buscar.value(4)

            ui.lineEditAdsc.setText(v_adsc)
            ui.lineEditTarjeta.setText(v_tarjeta)
            ui.lineEditNumEmp.setText(v_numemp)
            ui.lineEditNombre.setText(v_nombre)

            cargarVista(v_id_alf)
            ui.pushButtonAgregar.setEnabled(True)
            ui.pushButtonBuscar.focusNextChild()
    else:
        QMessageBox.critical(self, 'Error', 'Error al cargar datos',
                             QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)

def cargarVista(v_id_alf):
    query = "SELECT * FROM vaclic WHERE Id_alf = '%s" %v_id_alf + "'" + "order by 'Inicio' DESC"
    modelo = obtenerModelo(query)

    view = ui.tableViewRegistrosVacLic
    view.setModel(modelo)
    #view.sortByColumn(6)
    #view.hideColumn(0)
    #view.hideColumn(1)
    view.verticalHeader().setVisible(False)
    view.resizeColumnsToContents()
    view.show()

def insertarRegistro(self):
    if validarCampos(self):
        f_captura = QDate.currentDate().toString("dd-MMM-yyyy")
        h_captura = QTime.currentTime().toString("HH:mm")
        print("f_captura : " + f_captura)
        print("h_captura : " + h_captura)
        id_alf = globals()["v_id_alf"]

        i = ui.dateEditInicio.text()
        i1 = int(i[0:2])
        i2 = i[3:6]
        i3 = int(i[7:11])
        inicio = date(i3,2,i1)

        valores = "'" + str(id_alf) + "', "\
                    + "'" + (ui.lineEditFolio.text()) + "', "\
                    + "'" + (ui.lineEditClave.text()) + "', "\
                    + "'" + (ui.lineEditPeriodo.text()) + "', "\
                    + "'" + (ui.lineEditDias.text()) + "', "\
                    + "'" + str(inicio) + "', "\
                    + "'" + (ui.lineEditArt.text()) + "', "\
                    + "'" + (ui.lineEditUno.text()) + "', "\
                    + "'" + (ui.lineEditDos.text()) + "', "\
                    + "'" + (ui.lineEditTres.text()) + "', "\
                    + "'" + (ui.lineEditCuatro.text()) + "', "\
                    + "'" + (ui.lineEditCinco.text()) + "', "\
                    + "'" + (ui.lineEditSeis.text()) + "', "\
                    + "'" + (ui.lineEditSiete.text()) + "', "\
                    + "'" + (ui.lineEditOcho.text()) + "', "\
                    + "'" + (ui.lineEditNueve.text()) + "', "\
                    + "'" + (ui.lineEditDiez.text()) + "', "\
                    + "'" + (ui.lineEditNotas.text()) + "', "\
                    + "'" + f_captura + "', "\
                    + "'" + h_captura + "'"

        print("valores : " + valores)
        query = "INSERT INTO vaclic (" \
                "Id_alf, " \
                "Folio, " \
                "Clave, " \
                "PeriodoSerie, " \
                "Dias, " \
                "Inicio, " \
                "Articulo, " \
                "'1', " \
                "'2', " \
                "'3', " \
                "'4', " \
                "'5', " \
                "'6', " \
                "'7', " \
                "'8', " \
                "'9', " \
                "'10', " \
                "Notas, " \
                "'Fecha de Captura', " \
                "'Hora de Captura') " \
                "VALUES (" + valores + ")"
        print("query : " + query)
        datos = QSqlQuery()
        datos.prepare(query)

        if datos.exec_():
            limpiarCampos(self)
            cargarVista(v_id_alf)
            QMessageBox.information(self, 'Aviso', 'El registro se ingreso correctamente',
                                    QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)
        else:
            QMessageBox.critical(self, 'Error', 'El registro NO se pudo guardar',
                                 QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)

# VALIDAR LOS VALORES PERMITIDOS PARA ALGUNOS CAMPOS
def validarValoresPermitidos(self):
    rx = QRegExp

    rx_folio = rx("[1-9]\\d{5}")
    val_folio = QtGui.QRegExpValidator(rx_folio, self)
    ui.lineEditFolio.setValidator(val_folio)

    rx_clave = rx("[1-9]\\d{1}")
    val_clave = QtGui.QRegExpValidator(rx_clave, self)
    ui.lineEditClave.setValidator(val_clave)

    rx_dias = rx("[1-9]\\d{2}")
    val_dias = QtGui.QRegExpValidator(rx_dias, self)
    ui.lineEditDias.setValidator(val_dias)

    rx_articulo = rx("[0-9]\\d{1}\\.\\d{1}")
    val_articulo = QtGui.QRegExpValidator(rx_articulo, self)
    ui.lineEditArt.setValidator(val_articulo)

    rx_uno = rx("[0-9]\\d{1}\\-\\d{2}")
    val_uno = QtGui.QRegExpValidator(rx_uno, self)
    ui.lineEditUno.setValidator(val_uno)
    
    rx_dos = rx("[0-9]\\d{1}\\-\\d{2}")
    val_dos = QtGui.QRegExpValidator(rx_dos, self)
    ui.lineEditDos.setValidator(val_dos)
    
    rx_tres = rx("[0-9]\\d{1}\\-\\d{2}")
    val_tres = QtGui.QRegExpValidator(rx_tres, self)
    ui.lineEditTres.setValidator(val_tres)
    
    rx_cuatro = rx("[0-9]\\d{1}\\-\\d{2}")
    val_cuatro = QtGui.QRegExpValidator(rx_cuatro, self)
    ui.lineEditCuatro.setValidator(val_cuatro)
    
    rx_cinco = rx("[0-9]\\d{1}\\-\\d{2}")
    val_cinco = QtGui.QRegExpValidator(rx_cinco, self)
    ui.lineEditCinco.setValidator(val_cinco)
    
    rx_seis = rx("[0-9]\\d{1}\\-\\d{2}")
    val_seis = QtGui.QRegExpValidator(rx_seis, self)
    ui.lineEditSeis.setValidator(val_seis)
    
    rx_siete = rx("[0-9]\\d{1}\\-\\d{2}")
    val_siete = QtGui.QRegExpValidator(rx_siete, self)
    ui.lineEditSiete.setValidator(val_siete)
    
    rx_ocho = rx("[0-9]\\d{1}\\-\\d{2}")
    val_ocho = QtGui.QRegExpValidator(rx_ocho, self)
    ui.lineEditOcho.setValidator(val_ocho)
    
    rx_nueve = rx("[0-9]\\d{1}\\-\\d{2}")
    val_nueve = QtGui.QRegExpValidator(rx_nueve, self)
    ui.lineEditNueve.setValidator(val_nueve)
    
    rx_diez = rx("[0-9]\\d{1}\\-\\d{2}")
    val_diez = QtGui.QRegExpValidator(rx_diez, self)
    ui.lineEditDiez.setValidator(val_diez)

def validarCampos(self):
    global mensaje
    mensaje = ""
    datos_ok = False

    if ui.lineEditFolio.text() == "":
        mensaje = u'El campo "Folio" no puede quedar vacío'
    elif ui.lineEditClave.text() == "":
        mensaje = u'El campo "Clave" no puede quedar vacío'
    elif ui.lineEditDias.text() == "":
        mensaje = u'El campo "Días" no puede quedar vacío'

    if ui.lineEditClave.text() != "":
        clave = int(ui.lineEditClave.text())
        if ui.lineEditPeriodo.text() == "" and (clave>=50 and clave<=70):
            mensaje = u'El campo "Período/Serie" no puede quedar vacío'
        elif ui.lineEditArt.text() == "" and (clave<50 or clave>70):
            mensaje = u'El campo "Art." no puede quedar vacío'
        elif ui.lineEditUno.text() == "" and (clave>=60 and clave<70):
            mensaje = u"""La clave de registro corresponde a Vacaciones,\n
por lo que es necesario agregar las fechas correspondientes.\n
Utilice al menos el campo "1" para ello."""

    if mensaje != "":
        QMessageBox.critical(self, 'Error', mensaje,
                             QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)
    else:
        datos_ok = True

    return datos_ok

def limpiarCampos(self):
    ui.lineEditFolio.setText("")
    ui.lineEditClave.setText("")
    ui.lineEditPeriodo.setText("")
    ui.lineEditDias.setText("")
    ui.dateEditInicio.setDate(QDate.currentDate())
    ui.lineEditArt.setText("")
    ui.lineEditUno.setText("")
    ui.lineEditDos.setText("")
    ui.lineEditTres.setText("")
    ui.lineEditCuatro.setText("")
    ui.lineEditCinco.setText("")
    ui.lineEditSeis.setText("")
    ui.lineEditSiete.setText("")
    ui.lineEditOcho.setText("")
    ui.lineEditNueve.setText("")
    ui.lineEditDiez.setText("")
    ui.lineEditNotas.setText("")