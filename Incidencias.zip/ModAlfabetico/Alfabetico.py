#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Juan José Guzmán Cruz'
from PyQt5.QtCore import Qt
from PyQt5.QtSql import QSqlQuery
from PyQt5.QtWidgets import QMainWindow, QCompleter
from ModAlfabetico.AlfabeticoUI import Ui_mainWindowAlfabetico
from ModAlfabetico.ManejoAlfabetico import ManejoAlfabetico, obtenerDatos, opcionElegidaNuevoOModificar
from ModVacLic.VacLic import VacLic
from DataBase.ManejoBD import obtenerModelo

ui = Ui_mainWindowAlfabetico()
columns_table = ['id', 'adsc', 'tarjeta', 'numemp', 'nombre', 'plaza',
                 'rfc', 'puesto', 'nombramiento', 'servicio', 'turno',
                 'entrada', 'salida', 'observaciones', 'fecha_ingreso']

class Alfabetico(QMainWindow):

    # Función para iniciar la pantalla gráfica
    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)
        ui.setupUi(self)

        self.cargarVista()

        # BUSCAR SEGÚN LA COLUMNA 4 DE LA TABLA tableView_datos, EL DATO PRESENTE EL lineEditBuscar
        completer = QCompleter(ui.tableViewDatos.model())
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        completer.setCompletionColumn(4)
        ui.lineEditBuscar.setCompleter(completer)

    def on_lineEditBuscar_textChanged(self):
        texto = ui.lineEditBuscar.text()
        query = "SELECT * FROM alfabetico WHERE Tarjeta LIKE '" + texto + "%' " \
                "OR NumEmp LIKE '" + texto + "%' OR Nombre LIKE '%" + texto + "%'"
        enviarQuery(query)

    def on_pushButtonNuevo_released(self):
        self.w = ManejoAlfabetico()
        self.w.show()
        opcionElegidaNuevoOModificar(1)
        ui.lineEditBuscar.setText("")

    def on_pushButtonCerrar_released(self):
        exit(self)

    # SELECCIONAR UN REGISTRO DE LA tableView_datos CON DOBLE CLICK Y CARGAR ManejoAlfabeticoUI
    def on_tableViewDatos_doubleClicked(self, index):
        reg = index.data()
        col = index.column()

        if(index.column() == 0 or index.column() == 3 or index.column() == 4):
            query = "SELECT * FROM alfabetico WHERE " + columns_table[col] + " = '" + str(reg) + "'"
            consultar = QSqlQuery()
            consultar.prepare(query)

            if(consultar.exec_()):
                while(consultar.next()):
                    id = consultar.value(0)
                    adsc = consultar.value(1)
                    tarjeta = consultar.value(2)
                    numemp = consultar.value(3)
                    nombre = consultar.value(4)
                    plaza = consultar.value(5)
                    rfc = consultar.value(6)
                    puesto = consultar.value(7)
                    nombramiento = consultar.value(8)
                    servicio = consultar.value(9)
                    turno = consultar.value(10)
                    entrada = consultar.value(11)
                    salida = consultar.value(12)
                    observaciones = consultar.value(13)
                    fecha_ingreso = consultar.value(14)

                self.d = ManejoAlfabetico()
                opcionElegidaNuevoOModificar(2)
                obtenerDatos(id, adsc, tarjeta, numemp, nombre, plaza, rfc, puesto, nombramiento, servicio, turno, entrada, salida, observaciones, fecha_ingreso)
                self.d.show()
                ui.lineEditBuscar.setText("")
            else:
                print("No se cargaron los datos")
                print("ERROR!" + str(consultar.lastError()))

    def on_actionVacLic_triggered(self):
        self.w = VacLic()
        self.w.show()

    def cargarVista(self):
        query = "SELECT * FROM alfabetico"
        modelo = obtenerModelo(query)

        view = ui.tableViewDatos
        view.setModel(modelo)
        view.verticalHeader().setVisible(False)
        view.resizeColumnsToContents()
        view.show()

def enviarQuery(query):
    model = ui.tableViewDatos.model()
    model.setQuery(query)
