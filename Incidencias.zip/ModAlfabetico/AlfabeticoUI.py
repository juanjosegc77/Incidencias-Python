#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Juan José Guzmán Cruz'
# Form implementation generated from reading ui file 'Alfabetico.ui'
#
# Created: Wed Oct 21 17:52:43 2015
#
# WARNING! All changes made in this file will be lost!
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow, QWidget

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QApplication.translate(context, text, disambig)

class Ui_mainWindowAlfabetico(object):
    def setupUi(self, mainWindowAlfabetico):
        mainWindowAlfabetico.setObjectName(_fromUtf8("mainWindowAlfabetico"))
        mainWindowAlfabetico.setWindowModality(QtCore.Qt.ApplicationModal)
        mainWindowAlfabetico.resize(889, 630)
        mainWindowAlfabetico.setMinimumSize(QtCore.QSize(800, 600))
        mainWindowAlfabetico.setMaximumSize(QtCore.QSize(16777215, 16777215))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        mainWindowAlfabetico.setFont(font)
        mainWindowAlfabetico.setDockOptions(QMainWindow.AllowTabbedDocks|QMainWindow.AnimatedDocks)
        self.centralWidget = QWidget(mainWindowAlfabetico)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.centralWidget.sizePolicy().hasHeightForWidth())
        self.centralWidget.setSizePolicy(sizePolicy)
        self.centralWidget.setCursor(QtGui.QCursor(QtCore.Qt.ArrowCursor))
        self.centralWidget.setAutoFillBackground(False)
        self.centralWidget.setObjectName(_fromUtf8("centralWidget"))
        self.gridLayout_4 = QtWidgets.QGridLayout(self.centralWidget)
        self.gridLayout_4.setObjectName(_fromUtf8("gridLayout_4"))
        self.tableViewDatos = QtWidgets.QTableView(self.centralWidget)
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        font.setPointSize(11)
        font.setItalic(False)
        self.tableViewDatos.setFont(font)
        self.tableViewDatos.setEditTriggers(QtWidgets.QAbstractItemView.DoubleClicked)
        self.tableViewDatos.setProperty("showDropIndicator", False)
        self.tableViewDatos.setDragDropOverwriteMode(False)
        self.tableViewDatos.setObjectName(_fromUtf8("tableViewDatos"))
        self.gridLayout_4.addWidget(self.tableViewDatos, 3, 0, 3, 6)
        self.gridLayout_2 = QtWidgets.QGridLayout()
        self.gridLayout_2.setHorizontalSpacing(20)
        self.gridLayout_2.setVerticalSpacing(10)
        self.gridLayout_2.setObjectName(_fromUtf8("gridLayout_2"))
        self.labelBuscar = QtWidgets.QLabel(self.centralWidget)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Preferred, QtWidgets.QSizePolicy.Preferred)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.labelBuscar.sizePolicy().hasHeightForWidth())
        self.labelBuscar.setSizePolicy(sizePolicy)
        self.labelBuscar.setMinimumSize(QtCore.QSize(100, 0))
        self.labelBuscar.setMaximumSize(QtCore.QSize(16777215, 16777215))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.labelBuscar.setFont(font)
        self.labelBuscar.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.labelBuscar.setAlignment(QtCore.Qt.AlignCenter)
        self.labelBuscar.setObjectName(_fromUtf8("labelBuscar"))
        self.gridLayout_2.addWidget(self.labelBuscar, 0, 0, 1, 1)
        self.pushButtonNuevo = QtWidgets.QPushButton(self.centralWidget)
        self.pushButtonNuevo.setMinimumSize(QtCore.QSize(0, 50))
        self.pushButtonNuevo.setMaximumSize(QtCore.QSize(100, 16777215))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.pushButtonNuevo.setFont(font)
        self.pushButtonNuevo.setObjectName(_fromUtf8("pushButtonNuevo"))
        self.gridLayout_2.addWidget(self.pushButtonNuevo, 0, 2, 1, 1)
        self.lineEditBuscar = QtWidgets.QLineEdit(self.centralWidget)
        self.lineEditBuscar.setMinimumSize(QtCore.QSize(0, 0))
        self.lineEditBuscar.setMaximumSize(QtCore.QSize(16777215, 16777215))
        self.lineEditBuscar.setObjectName(_fromUtf8("lineEditBuscar"))
        self.gridLayout_2.addWidget(self.lineEditBuscar, 0, 1, 1, 1)
        self.pushButtonCerrar = QtWidgets.QPushButton(self.centralWidget)
        self.pushButtonCerrar.setMinimumSize(QtCore.QSize(0, 50))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Arial"))
        font.setPointSize(12)
        font.setBold(True)
        font.setWeight(75)
        self.pushButtonCerrar.setFont(font)
        self.pushButtonCerrar.setObjectName(_fromUtf8("pushButtonCerrar"))
        self.gridLayout_2.addWidget(self.pushButtonCerrar, 0, 3, 1, 1)
        self.gridLayout_4.addLayout(self.gridLayout_2, 0, 2, 1, 1)
        mainWindowAlfabetico.setCentralWidget(self.centralWidget)
        self.menuBar = QtWidgets.QMenuBar(mainWindowAlfabetico)
        self.menuBar.setGeometry(QtCore.QRect(0, 0, 889, 26))
        self.menuBar.setObjectName(_fromUtf8("menuBar"))
        self.menuCaptura = QtWidgets.QMenu(self.menuBar)
        self.menuCaptura.setObjectName(_fromUtf8("menuCaptura"))
        self.menuArchivo = QtWidgets.QMenu(self.menuBar)
        self.menuArchivo.setObjectName(_fromUtf8("menuArchivo"))
        mainWindowAlfabetico.setMenuBar(self.menuBar)
        self.mainToolBar = QtWidgets.QToolBar(mainWindowAlfabetico)
        self.mainToolBar.setObjectName(_fromUtf8("mainToolBar"))
        mainWindowAlfabetico.addToolBar(QtCore.Qt.TopToolBarArea, self.mainToolBar)
        self.toolBar = QtWidgets.QToolBar(mainWindowAlfabetico)
        self.toolBar.setObjectName(_fromUtf8("toolBar"))
        mainWindowAlfabetico.addToolBar(QtCore.Qt.TopToolBarArea, self.toolBar)
        self.statusBar = QtWidgets.QStatusBar(mainWindowAlfabetico)
        self.statusBar.setObjectName(_fromUtf8("statusBar"))
        mainWindowAlfabetico.setStatusBar(self.statusBar)
        self.actionAD42 = QtWidgets.QAction(mainWindowAlfabetico)
        self.actionAD42.setObjectName(_fromUtf8("actionAD42"))
        self.actionVacLic = QtWidgets.QAction(mainWindowAlfabetico)
        self.actionVacLic.setObjectName(_fromUtf8("actionVacLic"))
        self.menuCaptura.addAction(self.actionAD42)
        self.menuCaptura.addAction(self.actionVacLic)
        self.menuBar.addAction(self.menuArchivo.menuAction())
        self.menuBar.addAction(self.menuCaptura.menuAction())

        self.retranslateUi(mainWindowAlfabetico)
        QtCore.QMetaObject.connectSlotsByName(mainWindowAlfabetico)

    def retranslateUi(self, mainWindowAlfabetico):
        mainWindowAlfabetico.setWindowTitle(_translate("mainWindowAlfabetico", "Alfabetico", None))
        self.labelBuscar.setText(_translate("mainWindowAlfabetico", "Buscar", None))
        self.pushButtonNuevo.setText(_translate("mainWindowAlfabetico", "Nuevo", None))
        self.pushButtonCerrar.setText(_translate("mainWindowAlfabetico", "Cerrar", None))
        self.menuCaptura.setTitle(_translate("mainWindowAlfabetico", "Captura", None))
        self.menuArchivo.setTitle(_translate("mainWindowAlfabetico", "Archivo", None))
        self.toolBar.setWindowTitle(_translate("mainWindowAlfabetico", "toolBar", None))
        self.actionAD42.setText(_translate("mainWindowAlfabetico", "AD-42", None))
        self.actionVacLic.setText(_translate("mainWindowAlfabetico", "VacLic", None))

