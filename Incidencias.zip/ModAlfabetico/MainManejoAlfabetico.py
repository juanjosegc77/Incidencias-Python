#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Juan José Guzmán Cruz'
import sys

from PyQt5.QtWidgets import QApplication
from ModAlfabetico.ManejoAlfabetico import ManejoAlfabetico

if __name__ == "__main__":
    app = QApplication(sys.argv)
    MainWindow = ManejoAlfabetico()
    MainWindow.show()
    sys.exit(app.exec_())