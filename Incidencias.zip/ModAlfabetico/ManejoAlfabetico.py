#!/usr/bin/python
# -*- coding: utf-8 -*-

__author__ = 'Juan José Guzmán Cruz'
from PyQt5 import QtGui
from PyQt5.QtCore import QTime, QDate, QRegExp
from PyQt5.QtSql import QSqlQuery
from PyQt5.QtWidgets import QMainWindow, QMessageBox, QInputDialog, QCompleter
from numpy import unicode

from ModAlfabetico.ManejoAlfabeticoUI import Ui_dialogManejoAlfabetico

ui = Ui_dialogManejoAlfabetico()


class ManejoAlfabetico(QMainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)
        ui.setupUi(self)

        ui.pushButtonEliminar.setEnabled(False)

        datosComboBox(self)

        validarValoresPermitidos(self)

        datosRepetidos()

    # LLAMAR A LOS METODOS insertarRegistro ó modificarRegistro AL PRESIONAR EL BOTON GUARDAR
    def on_pushButtonGuardar_released(self):

        if choose == 1:
            if ui.lineEditNombre.text() == "":
                QMessageBox.critical(self, "Error", u"El campo \"Nombre\" es obligatorio, no puede estar vacío", 1, 0)
            else:
                reply = QMessageBox.question(self, "Confirmar", u"¿Está seguro de agregar este registro?",
                                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
                if reply == QMessageBox.Yes:
                    insertarRegistro(self)

        elif choose == 2:
            reply = QMessageBox.question(self, "Confirmar", u"¿Desea actualizar los datos?",
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                modificarRegistro(self)

    # LLAMAR A LA FUNCION eliminarRegistro AL PRESIONAR EL BOTON ELIMINAR
    def on_pushButtonEliminar_released(self):
        eliminarRegistro(self)

    # CIERRA LA VENTANA ManejoAlfabeticoUI
    def on_pushButtonCerrar_released(self):
         self.close()

    # PERMITE AGREGAR UN ELEMENTO NUEVO AL comboBoxAdsc
    def on_pushButtonAddAdsc_released(self):
        new_item = QInputDialog.getInt(self, "Nuevo elemento", u"Adscripción: ")
        add_item = str(new_item[0])
        ui.comboBoxAdsc.addItem(add_item)
        ui.comboBoxAdsc.setItemText(1, add_item)

    # PERMITE AGREGAR UN ELEMENTO NUEVO AL comboBoxDescPuesto
    def on_pushButtonAddDescPuesto_released(self):
        new_item = QInputDialog.getText(self, "Nuevo elemento", u"Descripción de Puesto: ")
        add_item = str(new_item[0]).upper()
        ui.comboBoxDescPuesto.addItem(add_item)
        ui.comboBoxDescPuesto.setItemText(1, add_item)

    # PERMITE AGREGAR UN ELEMENTO NUEVO AL comboBoxNombramiento
    def on_pushButtonAddNombramiento_released(self):
        new_item = QInputDialog.getText(self, "Nuevo elemento", "Nombramiento: ")
        add_item = str(new_item[0]).upper()
        ui.comboBoxNombramiento.addItem(add_item)
        ui.comboBoxNombramiento.setItemText(1, add_item)

    # PERMITE AGREGAR UN ELEMENTO NUEVO AL comboBoxServicio
    def on_pushButtonAddServicio_released(self):
        new_item = QInputDialog.getText(self, "Nuevo elemento", "Servicio: ")
        add_item = str(new_item[0]).upper()
        ui.comboBoxServicio.addItem(add_item)
        ui.comboBoxServicio.setItemText(1, add_item)

    # PERMITE AGREGAR UN ELEMENTO NUEVO AL comboBoxTurno
    def on_pushButtonAddTurno_released(self):
        new_item = QInputDialog.getText(self, "Nuevo elemento", "Turno: ")
        add_item = str(new_item[0]).upper()
        ui.comboBoxTurno.addItem(add_item)
        ui.comboBoxTurno.setItemText(1, add_item)

    # CONVERTIR A MAYUSCULAS LOS DATOS INGRESADOS EN EL lineEditTarjeta
    def on_lineEditTarjeta_textChanged(self):
        tarjeta = ui.lineEditTarjeta.text()
        ui.lineEditTarjeta.setText(tarjeta.upper())

    # CONVERTIR A MAYUSCULAS LOS DATOS INGRESADOS EN EL lineEditNombre
    def on_lineEditNombre_textChanged(self):
        nombre = ui.lineEditNombre.text()
        ui.lineEditNombre.setText(nombre.upper())

        # CAMBIAR EL COLOR DEL lineEditNombre AL ENCONTRAR REGISTROS REPETIDOS
        color = 'white'
        for x in l_nombre:
            if x == ui.lineEditNombre.text():
                color = 'red'

        ui.lineEditNombre.setStyleSheet('QLineEdit { background-color: %s }' % color)

    # CONVERTIR A MAYUSCULAS LOS DATOS INGRESADOS EN EL lineEditPlaza
    def on_lineEditPlaza_textChanged(self):
        plaza = ui.lineEditPlaza.text()
        ui.lineEditPlaza.setText(plaza.upper())

    # CONVERTIR A MAYUSCULAS LOS DATOS INGRESADOS EN EL lineEditRFC
    def on_lineEditRFC_textChanged(self):
        rfc = ui.lineEditRFC.text()
        ui.lineEditRFC.setText(rfc.upper())

    # CAMBIAR EL COLOR DEL lineEditNumEmp AL ENCONTRAR REGISTROS REPETIDOS
    def on_lineEditNumEmp_textChanged(self):
        color = 'white'
        for x in l_numemp:
            if x == ui.lineEditNumEmp.text():
                color = 'red'

        ui.lineEditNumEmp.setStyleSheet('QLineEdit { background-color: %s }' % color)


# INSERTAR NUEVO REGISTRO
def insertarRegistro(self):
    valores = "'" + (ui.comboBoxAdsc.currentText()) + "', "\
            + "'" + (ui.lineEditTarjeta.text()) + "', "\
            + "'" + (ui.lineEditNumEmp.text()) + "', "\
            + "'" + (ui.lineEditNombre.text()) + "', "\
            + "'" + (ui.lineEditPlaza.text()) + "', "\
            + "'" + (ui.lineEditRFC.text()) + "', "\
            + "'" + (ui.comboBoxDescPuesto.currentText()) + "', "\
            + "'" + (ui.comboBoxNombramiento.currentText()) + "', "\
            + "'" + (ui.comboBoxServicio.currentText()) + "', "\
            + "'" + (ui.comboBoxTurno.currentText()) + "', "\
            + "'" + (ui.timeEditEntrada.text()) + "', "\
            + "'" + (ui.timeEditSalida.text()) + "', "\
            + "'" + (ui.textEditObservaciones.toPlainText()) + "', "\
            + "'" + (ui.dateEditFechaDeIngreso.text()) + "'"

    query = "INSERT INTO alfabetico (" \
            "Adsc, " \
            "Tarjeta, " \
            "NumEmp, " \
            "Nombre, " \
            "Plaza, " \
            "RFC, " \
            "DescPuesto, " \
            "Nombramiento, " \
            "Servicio, " \
            "Turno, " \
            "Entrada, " \
            "Salida, " \
            "Observaciones, " \
            "'Fecha de Ingreso') " \
            "VALUES (" + valores + ")"

    datos = QSqlQuery()
    datos.prepare(query)

    if datos.exec_():
        QMessageBox.information(self, 'Aviso', "El registro se ingreso correctamente",
                                QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)
        self.close()
    else:
        QMessageBox.critical(self, 'Error', 'El registro NO se pudo guardar',
                             QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)


# MODIFICAR UN REGISTRO
def modificarRegistro(self):
    query = ("UPDATE alfabetico SET "
             "Adsc='"+ui.comboBoxAdsc.currentText()+"',"
             "Tarjeta='"+ui.lineEditTarjeta.text()+"',"
             "NumEmp='"+ui.lineEditNumEmp.text()+"',"
             "Nombre='"+ui.lineEditNombre.text()+"',"
             "Plaza='"+ui.lineEditPlaza.text()+"',"
             "RFC='"+ui.lineEditRFC.text()+"',"
             "DescPuesto='"+ui.comboBoxDescPuesto.currentText()+"',"
             "Nombramiento='"+ui.comboBoxNombramiento.currentText()+"',"
             "Servicio='"+ui.comboBoxServicio.currentText()+"',"
             "Turno='"+ui.comboBoxTurno.currentText()+"',"
             "Entrada='"+ui.timeEditEntrada.text()+"',"
             "Salida='"+ui.timeEditSalida.text()+"',"
             "Observaciones='"+ui.textEditObservaciones.toPlainText()+"',"
             "'Fecha de Ingreso'='"+ui.dateEditFechaDeIngreso.text()+"'"
             "WHERE Id='" + str(find_id) + "'")

    actualizar = QSqlQuery()
    actualizar.prepare(query)

    if actualizar.exec_():
        QMessageBox.information(self, "Aviso", u"El registro se actualizó correctamente",
                                QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)
        self.close()
    else:
        QMessageBox.critical(self, "Error", u"NO se actualizó el registro",
                             QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)


# ELIMINAR UN REGISTRO AL PRESIONAR EL BOTON ELIMINAR
def eliminarRegistro(self):
    reply = QMessageBox.question(self, 'Confirmar', "¿Está seguro de eliminar este registro?",
                                 QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
    if reply == QMessageBox.Yes:
        query = ("DELETE FROM alfabetico WHERE Id='" + str(find_id) + "'")

        consultar = QSqlQuery()
        consultar.prepare(query)

        if consultar.exec_():
            QMessageBox.information(self, 'Aviso', "El registro se eliminó correctamente",
                                    QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)
            self.close()
        else:
            QMessageBox.critical(self, 'Error', 'El registro NO se pudo eliminar. Error en query',
                                 QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)


# CARGA LOS VALORES A LOS ComboBox
# LOS VALORES SON OBTENIDOS DE LOS REGITRADOS EN LA BASE DE DATOS, EVITANDO ESPACIOS EN BLANCO Y ELIMINANDO REPETIDOS
# CUALQUIERA DE ESTOS DATOS ESTA ASOCIADO AL Id DE ALGUN REGISTRO, NO SE PUEDEN ELIMINAR POR SI SOLOS. ES NECESARIO
# MODIFICAR O ELIMINAR EL REGISTRO AL QUE ESTA ASOCIADO DICHO VALOR.
def datosComboBox(self):
    l_adsc = []
    l_desc_puesto = []
    l_nombramiento = []
    l_servicio = []
    l_turno = []

    query = "SELECT Adsc, DescPuesto, Nombramiento, Servicio, Turno FROM alfabetico"
    datos = QSqlQuery()
    datos.prepare(query)

    if datos.exec_():
        while datos.next():
            v_adsc = datos.value(0)
            v_desc_puesto = datos.value(1)
            v_nombramiento = datos.value(2)
            v_servicio = datos.value(3)
            v_turno = datos.value(4)
            if(v_adsc != "" or v_desc_puesto != "" or v_nombramiento != "" or v_servicio != "" or v_turno != ""):
                l_adsc.append(v_adsc)
                l_desc_puesto.append(v_desc_puesto)
                l_nombramiento.append(v_nombramiento)
                l_servicio.append(v_servicio)
                l_turno.append(v_turno)

        l_adsc = list(set(l_adsc))
        l_adsc.sort()
        ui.comboBoxAdsc.addItems(l_adsc)
        ui.comboBoxAdsc.setCurrentIndex(1)

        l_desc_puesto = list(set(l_desc_puesto))
        l_desc_puesto.sort()
        ui.comboBoxDescPuesto.addItems(l_desc_puesto)
        ui.comboBoxDescPuesto.setCurrentIndex(1)

        l_nombramiento = list(set(l_nombramiento))
        l_nombramiento.sort()
        ui.comboBoxNombramiento.addItems(l_nombramiento)
        ui.comboBoxNombramiento.setCurrentIndex(1)

        l_servicio = list(set(l_servicio))
        l_servicio.sort()
        ui.comboBoxServicio.addItems(l_servicio)
        ui.comboBoxServicio.setCurrentIndex(1)

        l_turno = list(set(l_turno))
        l_turno.sort()
        ui.comboBoxTurno.addItems(l_turno)
        ui.comboBoxTurno.setCurrentIndex(1)
    else:
        QMessageBox.critical(self, 'Error',
                             'Error al cargar datos en Combos',
                             QMessageBox.Ok | QMessageBox.NoButton, QMessageBox.Ok)
        print("ERROR!", datos.lastError())


# OBTENER DE LA BASE DE DATOS, LOS DATOS DEL REGISTRO A ELIMINAR O ACTUALIZAR
def obtenerDatos(id, adsc, tarjeta, numemp, nombre, plaza, rfc,
                        puesto, nombramiento, servicio, turno, entrada,
                        salida, observaciones, fecha_ingreso):
    ui.pushButtonEliminar.setEnabled(True)

    global find_id
    find_id = id
    ui.comboBoxAdsc.setItemText(1, adsc)
    ui.lineEditTarjeta.setText(tarjeta)
    ui.lineEditNumEmp.setText(numemp)
    ui.lineEditNombre.setText(nombre)
    ui.lineEditPlaza.setText(plaza)
    ui.lineEditRFC.setText(rfc)
    ui.comboBoxDescPuesto.setItemText(1, puesto)
    ui.comboBoxNombramiento.setItemText(1, nombramiento)
    ui.comboBoxServicio.setItemText(1, servicio)
    ui.comboBoxTurno.setItemText(1, turno)
    ui.timeEditEntrada.setTime(QTime.fromString(entrada, "HH:mm"))
    ui.timeEditSalida.setTime(QTime.fromString(salida, "HH:mm"))
    ui.textEditObservaciones.setText(observaciones)
    ui.dateEditFechaDeIngreso.setDate(QDate.fromString(fecha_ingreso, "dd-MMM-yyyy"))


# SE ASIGNA UN VALOR A LA VARIABLE choose DEL METODO nueMod (nuevo-modificar)
# choose ES 1, SI SE PRESIONO EL BOTON "NUEVO" DE LA VENTANA Alfabetico.ui
# choose ES 2, SI SE HIZO DOBLE CLICK EN EL Id DE ALGUN REGISTRO DE LA VENTANA Alfabetico.ui
def opcionElegidaNuevoOModificar(option):
    global choose
    choose = option
    if choose == 2:
        ui.pushButtonEliminar.setEnabled(True)
        ui.lineEditNombre.setStyleSheet('QLineEdit { background-color: white}')
        ui.lineEditNumEmp.setStyleSheet('QLineEdit { background-color: white}')


# VALIDAR LOS VALORES PERMITIDOS PARA ALGUNOS CAMPOS
def validarValoresPermitidos(self):
        rx = QRegExp

        rx_tarjeta = rx("[gGtT1-9]\\d{3}")
        val_tarjeta = QtGui.QRegExpValidator(rx_tarjeta, self)
        ui.lineEditTarjeta.setValidator(val_tarjeta)

        rx_numemp = rx("[1-9]\\d{5}")
        val_numemp = QtGui.QRegExpValidator(rx_numemp, self)
        ui.lineEditNumEmp.setValidator(val_numemp)

        rx_nombre = rx(u'[A-Za-zñÑ ]{100}')
        val_nombre = QtGui.QRegExpValidator(rx_nombre, self)
        ui.lineEditNombre.setValidator(val_nombre)


# SE CARGAN LOS NUMEMP Y NOMBRE DE LA BASE DE DATOS PARA QUE EL USUARIO PUEDA VER CUANDO SE REPITE UN REGISTRO
def datosRepetidos():
    query = "SELECT Nombre, NumEmp FROM alfabetico"
    consultar = QSqlQuery()
    consultar.prepare(query)
    global l_nombre, l_numemp
    l_nombre = []
    l_numemp = []
    if(consultar.exec_()):
        while consultar.next():
            l_nombre.append(unicode(consultar.value(0)))
            l_numemp.append(unicode(consultar.value(1)))

    c_nombre = QCompleter(l_nombre)
    ui.lineEditNombre.setCompleter(c_nombre)

    c_numemp = QCompleter(l_numemp)
    ui.lineEditNumEmp.setCompleter(c_numemp)
