#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Juan José Guzmán Cruz'

import sqlite3

def connectDB():

    conn = sqlite3.connect('DataBase/Incidencias.sqlite')

    conn.execute('''CREATE TABLE IF NOT EXISTS alfabetico
             (Id INTEGER PRIMARY KEY UNIQUE,
             Adsc TEXT,
             Tarjeta TEXT,
             NumEmp TEXT,
             Nombre TEXT,
             Plaza TEXT,
             RFC TEXT,
             DescPuesto TEXT,
             Nombramiento TEXT,
             Servicio TEXT,
             Turno TEXT,
             Entrada TEXT,
             Salida TEXT,
             Observaciones TEXT,
             'Fecha de Ingreso' TEXT);''')

    conn.execute('''CREATE TABLE IF NOT EXISTS vaclic
                 (Id_vaclic INTEGER PRIMARY KEY UNIQUE,
                 Id_alf INTEGER NOT NULL,
                 Folio TEXT,
                 Clave TEXT,
                 PeriodoSerie TEXT,
                 Dias TEXT,
                 Inicio TEXT,
                 Articulo TEXT,
                 '1' TEXT,
                 '2' TEXT,
                 '3' TEXT,
                 '4' TEXT,
                 '5' TEXT,
                 '6' TEXT,
                 '7' TEXT,
                 '8' TEXT,
                 '9' TEXT,
                 '10' TEXT,
                 'Notas' TEXT,
                 'Fecha de captura' TEXT,
                 'Hora de captura' TEXT,
                 FOREIGN KEY (Id_alf) REFERENCES alfabetico(Id) 
                 ON DELETE CASCADE ON UPDATE CASCADE);''')

    conn.close()