#!/usr/bin/python
# -*- coding: utf-8 -*-
__author__ = 'Juan José Guzmán Cruz'
from PyQt5.QtSql import QSqlDatabase, QSqlQueryModel


def obtenerModelo(query):
    db = QSqlDatabase.addDatabase("QSQLITE")
    db.setDatabaseName("DataBase/Incidencias.sqlite")
    db.open()

    model = QSqlQueryModel()
    model.setQuery(query)

    return model
