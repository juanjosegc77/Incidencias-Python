#!/usr/bin/python
# -*- coding: utf-8 -*-
from DataBase.ConnectionDB import connectDB

__author__ = 'Juan José Guzmán Cruz'

import sys

from PyQt5.QtWidgets import QApplication

from ModAlfabetico.Alfabetico import Alfabetico

if __name__ == "__main__":
    connectDB()
    app = QApplication(sys.argv)
    MainWindow = Alfabetico()
    MainWindow.show()
    sys.exit(app.exec_())